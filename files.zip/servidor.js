const express = require('express');
const multer = require('multer');
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

// Estado en memoria
let state = {
  people: [],
  tools: [],
  assignments: [],
  usageLog: []
};

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Rutas
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API: Cargar archivos Excel
app.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(firstSheet);

    // Detectar tipo de archivo
    const firstRow = data[0];
    if (firstRow['Nombre'] && firstRow['Proveedor']) {
      // Es archivo de personal
      state.people = data.map((row, idx) => ({
        id: idx,
        code: String(row['Proveedor'] || '').trim(),
        name: String(row['Nombre'] || '').trim()
      })).filter(p => p.code && p.name);
      res.json({ type: 'personal', count: state.people.length });
    } else if (firstRow['Cod Mat'] && firstRow['Descripción']) {
      // Es archivo SAP
      state.tools = data
        .filter(row => row['Cod Mat'] && row['Descripción'])
        .map((row, idx) => ({
          id: idx,
          code: String(row['Cod Mat']).trim(),
          name: String(row['Descripción']).trim(),
          almacen: String(row['Alma'] || ''),
          cant: Number(row['Cant']) || 0
        }))
        .filter((t, i, arr) => arr.findIndex(x => x.code === t.code) === i);
      res.json({ type: 'sap', count: state.tools.length });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API: Obtener estado
app.get('/api/state', (req, res) => {
  res.json(state);
});

// API: Asignar herramienta
app.post('/api/assign', (req, res) => {
  try {
    const { personId, toolId, qty } = req.body;
    const person = state.people[personId];
    const tool = state.tools[toolId];

    if (!person || !tool) {
      return res.status(400).json({ error: 'Persona o herramienta no encontrada' });
    }

    if (tool.cant < qty) {
      return res.status(400).json({ error: 'Stock insuficiente' });
    }

    state.assignments.push({
      id: Date.now(),
      personId,
      person,
      toolId,
      tool,
      qty,
      date: new Date().toLocaleDateString('es-CO')
    });

    state.tools[toolId].cant -= qty;
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API: Devolver herramienta
app.post('/api/return', (req, res) => {
  try {
    const { assignmentId } = req.body;
    const assignment = state.assignments.find(a => a.id === assignmentId);

    if (!assignment) {
      return res.status(400).json({ error: 'Asignación no encontrada' });
    }

    state.usageLog.push({
      id: Date.now(),
      person: assignment.person.name,
      personCode: assignment.person.code,
      tool: assignment.tool.name,
      toolCode: assignment.tool.code,
      qty: assignment.qty,
      time: new Date().toLocaleString('es-CO')
    });

    state.assignments = state.assignments.filter(a => a.id !== assignmentId);
    state.tools[assignment.toolId].cant += assignment.qty;
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API: Descargar Excel
app.get('/api/download', (req, res) => {
  try {
    const data = [];
    
    state.assignments.forEach(a => {
      data.push({
        'Código Personal': a.person.code,
        'Persona': a.person.name,
        'Código Herramienta': a.tool.code,
        'Herramienta': a.tool.name,
        'Almacén': a.tool.almacen,
        'Cantidad': a.qty,
        'Fecha': a.date
      });
    });

    state.tools.forEach(t => {
      if (!state.assignments.find(a => a.toolId === t.id)) {
        data.push({
          'Código Personal': '',
          'Persona': '',
          'Código Herramienta': t.code,
          'Herramienta': t.name,
          'Almacén': t.almacen,
          'Cantidad': t.cant,
          'Fecha': ''
        });
      }
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Inventario');
    
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=inventario-herramientas.xlsx');
    
    res.send(XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' }));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✓ Servidor activo en http://localhost:${PORT}`);
  console.log(`✓ Abre en tu iPad: http://[tu-IP]:${PORT}`);
});
